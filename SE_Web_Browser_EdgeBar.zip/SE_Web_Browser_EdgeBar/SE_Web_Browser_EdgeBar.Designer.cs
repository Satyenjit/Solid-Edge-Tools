﻿using System.Windows.Forms;

namespace DemoAddIn
{
    partial class SE_Web_Browser_EdgeBar
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.SE_WebBrowser = new System.Windows.Forms.WebBrowser();
            this.txtAdress = new System.Windows.Forms.RichTextBox();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.btnOpenInBrowser = new System.Windows.Forms.Button();
            this.btnGo = new System.Windows.Forms.Button();
            this.btnHome = new System.Windows.Forms.Button();
            this.btnRefresh = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // SE_WebBrowser
            // 
            this.SE_WebBrowser.Location = new System.Drawing.Point(0, 53);
            this.SE_WebBrowser.MinimumSize = new System.Drawing.Size(20, 20);
            this.SE_WebBrowser.Name = "SE_WebBrowser";
            this.SE_WebBrowser.Size = new System.Drawing.Size(398, 578);
            this.SE_WebBrowser.TabIndex = 0;
            // 
            // txtAdress
            // 
            this.txtAdress.AcceptsTab = true;
            this.txtAdress.DetectUrls = false;
            this.txtAdress.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAdress.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.txtAdress.Location = new System.Drawing.Point(101, 1);
            this.txtAdress.Multiline = false;
            this.txtAdress.Name = "txtAdress";
            this.txtAdress.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.Horizontal;
            this.txtAdress.Size = new System.Drawing.Size(191, 32);
            this.txtAdress.TabIndex = 3;
            this.txtAdress.Text = "";
            this.txtAdress.TextChanged += new System.EventHandler(this.Browser_Text_Changed);
            this.txtAdress.KeyDown += new System.Windows.Forms.KeyEventHandler(this.SE_Web_Browser_EdgeBar_KeyDown);
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(61, 4);
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.groupBox1.Location = new System.Drawing.Point(4, 37);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(381, 10);
            this.groupBox1.TabIndex = 5;
            this.groupBox1.TabStop = false;
            // 
            // btnOpenInBrowser
            // 
            this.btnOpenInBrowser.BackColor = System.Drawing.Color.DarkSlateGray;
            this.btnOpenInBrowser.Image = global::SE_Web_Browser_EdgeBar.Properties.Resources.Browser_icon;
            this.btnOpenInBrowser.Location = new System.Drawing.Point(343, 1);
            this.btnOpenInBrowser.Name = "btnOpenInBrowser";
            this.btnOpenInBrowser.Size = new System.Drawing.Size(39, 32);
            this.btnOpenInBrowser.TabIndex = 6;
            this.btnOpenInBrowser.UseVisualStyleBackColor = false;
            this.btnOpenInBrowser.Click += new System.EventHandler(this.btnOpenInBrowser_Click);
            // 
            // btnGo
            // 
            this.btnGo.BackColor = System.Drawing.Color.Olive;
            this.btnGo.Image = global::SE_Web_Browser_EdgeBar.Properties.Resources.Button_Next_icon;
            this.btnGo.Location = new System.Drawing.Point(298, 1);
            this.btnGo.Name = "btnGo";
            this.btnGo.Size = new System.Drawing.Size(39, 32);
            this.btnGo.TabIndex = 5;
            this.btnGo.UseVisualStyleBackColor = false;
            this.btnGo.Click += new System.EventHandler(this.btnGo_Click);
            // 
            // btnHome
            // 
            this.btnHome.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnHome.Image = global::SE_Web_Browser_EdgeBar.Properties.Resources.home_icon;
            this.btnHome.Location = new System.Drawing.Point(47, 1);
            this.btnHome.Name = "btnHome";
            this.btnHome.Size = new System.Drawing.Size(39, 32);
            this.btnHome.TabIndex = 2;
            this.btnHome.UseVisualStyleBackColor = false;
            this.btnHome.Click += new System.EventHandler(this.btnHome_Click);
            // 
            // btnRefresh
            // 
            this.btnRefresh.BackColor = System.Drawing.Color.OliveDrab;
            this.btnRefresh.Image = global::SE_Web_Browser_EdgeBar.Properties.Resources.Button_Refresh_icon;
            this.btnRefresh.Location = new System.Drawing.Point(2, 1);
            this.btnRefresh.Name = "btnRefresh";
            this.btnRefresh.Size = new System.Drawing.Size(39, 32);
            this.btnRefresh.TabIndex = 1;
            this.btnRefresh.UseVisualStyleBackColor = false;
            this.btnRefresh.Click += new System.EventHandler(this.btnRefresh_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.ErrorImage = global::SE_Web_Browser_EdgeBar.Properties.Resources.Info;
            this.pictureBox1.Image = global::SE_Web_Browser_EdgeBar.Properties.Resources.Info;
            this.pictureBox1.InitialImage = global::SE_Web_Browser_EdgeBar.Properties.Resources.Info;
            this.pictureBox1.Location = new System.Drawing.Point(387, 28);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(24, 25);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox1.TabIndex = 7;
            this.pictureBox1.TabStop = false;
            // 
            // SE_Web_Browser_EdgeBar
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.btnOpenInBrowser);
            this.Controls.Add(this.btnGo);
            this.Controls.Add(this.txtAdress);
            this.Controls.Add(this.btnHome);
            this.Controls.Add(this.btnRefresh);
            this.Controls.Add(this.SE_WebBrowser);
            this.Name = "SE_Web_Browser_EdgeBar";
            this.Size = new System.Drawing.Size(495, 635);
            this.ToolTip = "SE Web Browser";
            this.AfterInitialize += new System.EventHandler(this.SE_Web_Browser_EdgeBar_AfterInitialize);
            this.Load += new System.EventHandler(this.SE_Web_Browser_EdgeBar_Load);
            this.SizeChanged += new System.EventHandler(this.SE_Web_Browser_EdgeBar_SizeChanged_1);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }        

        #endregion

        private System.Windows.Forms.WebBrowser SE_WebBrowser;
        private Button btnRefresh;
        private Button btnHome;
        private RichTextBox txtAdress;
        private ContextMenuStrip contextMenuStrip1;
        private Button btnGo;
        private Button btnOpenInBrowser;
        private GroupBox groupBox1;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private PictureBox pictureBox1;
    }
}
