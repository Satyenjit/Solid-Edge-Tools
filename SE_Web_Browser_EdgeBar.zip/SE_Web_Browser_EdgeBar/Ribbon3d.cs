﻿using SolidEdgeCommunity.AddIn;
using SolidEdgeCommunity.Extensions; // https://github.com/SolidEdgeCommunity/SolidEdge.Community/wiki/Using-Extension-Methods
using SolidEdgeFramework;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using System.Security.AccessControl;
using SEInstallDataLib;
using Microsoft.Win32;

namespace DemoAddIn
{

    class Ribbon3d : SolidEdgeCommunity.AddIn.Ribbon
    {
        const string        _embeddedResourceName = "DemoAddIn.Ribbon3d.xml";        

        public Ribbon3d()
        {
            // Get a reference to the current assembly. This is where the ribbon XML is embedded.
            var assembly = System.Reflection.Assembly.GetExecutingAssembly();

            // In this example, XML file must have a build action of "Embedded Resource".
            this.LoadXml(assembly, _embeddedResourceName);

            // Get the Solid Edge version.
            var version = DemoAddIn.Instance.SolidEdgeVersion;
        }               

    }
}

