﻿using SolidEdgeCommunity.Extensions; // https://github.com/SolidEdgeCommunity/SolidEdge.Community/wiki/Using-Extension-Methods
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using SolidEdgeFramework;
using System.IO;
using Microsoft.Win32;
using System.Diagnostics;

namespace DemoAddIn
{

    // Custom web browser control: Satyen [02/07/2020]
    public partial class SE_Web_Browser_EdgeBar : SolidEdgeCommunity.AddIn.EdgeBarControl
    {
        string strHomePage = "https://www.linkedin.com/login?fromSignIn=true&trk=guest_homepage-basic_nav-header-signin";
        string strTestwebPage = "https://www.linkedin.com/login?fromSignIn=true&trk=guest_homepage-basic_nav-header-signin";

        public SE_Web_Browser_EdgeBar()
        {
            InitializeComponent();
        }

        private void SE_Web_Browser_EdgeBar_Load(object sender, EventArgs e)
        {
            // Trick to use the default system font.
            this.Font = SystemFonts.MessageBoxFont;
        }

        private void SE_Web_Browser_EdgeBar_SizeChanged(object sender, EventArgs e)
        {

        }

        // Navigation logic: Satyen [02/07/2020]
        private void SE_Web_Browser_EdgeBar_AfterInitialize(object sender, EventArgs e)
        {
            // Create the ToolTip and associate with the Form container.
            ToolTip toolTip1 = new ToolTip();            
            toolTip1.ToolTipTitle = "Go..";            
            toolTip1.SetToolTip(this.btnGo, "Load the entered web page..");
            SettoolTipProps(toolTip1);

            // Set tooltip props
            ToolTip toolTip2 = new ToolTip();            
            toolTip2.ToolTipTitle = "Home";            
            toolTip2.SetToolTip(this.btnHome, "Go to the home page of browser.");
            SettoolTipProps(toolTip2);

            ToolTip toolTip3 = new ToolTip();            
            toolTip3.ToolTipTitle = "Reload..";            
            toolTip3.SetToolTip(this.btnRefresh, "Reload the current web page..");
            SettoolTipProps(toolTip3);

            ToolTip toolTip4 = new ToolTip();            
            toolTip4.ToolTipTitle = "Open in Browser..";            
            toolTip4.SetToolTip(this.btnOpenInBrowser, "Open this web page in a browser application.");
            SettoolTipProps(toolTip4);

            ToolTip toolTip6 = new ToolTip();
            toolTip6.ToolTipTitle = "Free Add-In: Web browser control in Solid Edge UI";
            toolTip6.SetToolTip(this.pictureBox1, "@ Developed by Satyen");
            SettoolTipProps(toolTip6);
        
        // Address bar
        txtAdress.Text = strHomePage;            

            var edgeBarPage = this.EdgeBarPage;
            var document = this.Document;
            var seApp = document.Application;
            SolidEdgeDocument docActive = seApp.GetActiveDocument();

            SE_WebBrowser.ScriptErrorsSuppressed = true;
            SE_WebBrowser.Navigate(strTestwebPage);
        }

        // Monday, February 10, 2020 
        void SettoolTipProps(ToolTip tlpIn)
        {
            tlpIn.ShowAlways = true;
            //tlpIn.ToolTipIcon = ToolTipIcon.Info;
            tlpIn.UseAnimation = true;
            tlpIn.IsBalloon = true;
            tlpIn.ShowAlways = true;
            tlpIn.InitialDelay = 100;
        }

        private void SE_Web_Browser_EdgeBar_KeyDown(object sender, System.Windows.Forms.KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                SE_WebBrowser.Navigate(txtAdress.Text);
            }
        }

        private void SetIE8KeyforWebBrowserControl(string appName)
        {
            RegistryKey Regkey = null;
            try
            {
                // For 64 bit machine
                if (System.Environment.Is64BitOperatingSystem)
                    Regkey = Microsoft.Win32.Registry.LocalMachine.OpenSubKey(@"SOFTWARE\\Wow6432Node\\Microsoft\\Internet Explorer\\MAIN\\FeatureControl\\FEATURE_BROWSER_EMULATION", true);
                else  //For 32 bit machine
                    Regkey = Microsoft.Win32.Registry.LocalMachine.OpenSubKey(@"SOFTWARE\\Microsoft\\Internet Explorer\\Main\\FeatureControl\\FEATURE_BROWSER_EMULATION", true);

                // If the path is not correct or
                // if the user haven't priviledges to access the registry
                if (Regkey == null)
                {
                    MessageBox.Show("Application Settings Failed - Address Not found");
                    return;
                }

                string FindAppkey = Convert.ToString(Regkey.GetValue(appName));

                // Check if key is already present
                if (FindAppkey == "8000")
                {
                    MessageBox.Show("Required Application Settings Present");
                    Regkey.Close();
                    return;
                }

                // If a key is not present add the key, Key value 8000 (decimal)
                if (string.IsNullOrEmpty(FindAppkey))
                    Regkey.SetValue(appName, unchecked((int)0x1F40), RegistryValueKind.DWord);

                // Check for the key after adding
                FindAppkey = Convert.ToString(Regkey.GetValue(appName));

                if (FindAppkey == "8000")
                    MessageBox.Show("Application Settings Applied Successfully");
                else
                    MessageBox.Show("Application Settings Failed, Ref: " + FindAppkey);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Application Settings Failed");
                MessageBox.Show(ex.Message);
            }
            finally
            {
                // Close the Registry
                if (Regkey != null)
                    Regkey.Close();
            }

        }

        private void btnHome_Click(object sender, EventArgs e)
        {
            SE_WebBrowser.Navigate("www.google.ca");
            txtAdress.Text = "www.google.ca";
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            SE_WebBrowser.Refresh();
        }

        private void btnGo_Click(object sender, EventArgs e)
        {
            SE_WebBrowser.Navigate(txtAdress.Text);
        }

        // We have to reset the control size - // Monday, February 10, 2020.
        private void SE_Web_Browser_EdgeBar_SizeChanged_1(object sender, EventArgs e)
        {
            SE_WebBrowser.Width = this.Width;
            SE_WebBrowser.Height = this.Height - 20;
        }

        private void btnOpenInBrowser_Click(object sender, EventArgs e)
        {
            if(txtAdress.Text != "")
                Process.Start(txtAdress.Text);
        }

        private void Browser_Text_Changed(object sender, EventArgs e)
        {
            ToolTip toolTip5 = new ToolTip();       
            toolTip5.SetToolTip(this.txtAdress, txtAdress.Text);
            SettoolTipProps(toolTip5);

        }

    }
}
